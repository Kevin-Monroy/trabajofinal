import React from "react";
import { Link } from "react-router-dom";
import "../assets/styles.css"; // Para los estilos

function HomePage() {
  return (
    <div className="home">
      <h1>🌿 Tienda de Plantas 🌿</h1>
      <p>Bienvenido a nuestra tienda, donde encontrarás las mejores plantas de interior.</p>
      <Link to="/productos">
        <button className="btn">Comenzar</button>
      </Link>
    </div>
  );
}

export default HomePage;
