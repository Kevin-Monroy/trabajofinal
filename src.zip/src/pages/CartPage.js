import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { removeFromCart, increaseQuantity, decreaseQuantity } from "../redux/cartSlice";

function CartPage() {
  const cartItems = useSelector(state => state.cart.items);
  const dispatch = useDispatch();

  const totalPrice = cartItems.reduce((total, item) => total + item.price, 0);

  return (
    <div>
      <h2>🛒 Carrito de Compras</h2>
      {cartItems.length === 0 ? (
        <p>Tu carrito está vacío.</p>
      ) : (
        cartItems.map(item => (
          <div key={item.id} className="cart-item">
            <h3>{item.name}</h3>
            <p>💲 {item.price}</p>
            <button onClick={() => dispatch(increaseQuantity(item.id))}>➕</button>
            <button onClick={() => dispatch(decreaseQuantity(item.id))}>➖</button>
            <button onClick={() => dispatch(removeFromCart(item.id))}>❌</button>
          </div>
        ))
      )}
      <h3>Total: 💲{totalPrice}</h3>
    </div>
  );
}

export default CartPage;
