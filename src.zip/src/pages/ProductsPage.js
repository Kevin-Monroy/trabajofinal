import React from "react";
import { useDispatch } from "react-redux";
import { addToCart } from "../redux/cartSlice";

const plants = [
  { id: 1, name: "Monstera", price: 20 },
  { id: 2, name: "Ficus", price: 15 },
  { id: 3, name: "Cactus", price: 10 },
  { id: 4, name: "Aloe Vera", price: 12 },
  { id: 5, name: "Orquídea", price: 25 },
  { id: 6, name: "Helecho", price: 18 },
];

function ProductsPage() {
  const dispatch = useDispatch();

  return (
    <div>
      <h2>Nuestras Plantas</h2>
      <div className="product-list">
        {plants.map((plant) => (
          <div key={plant.id} className="product">
            <h3>{plant.name}</h3>
            <p>💲 {plant.price}</p>
            <button onClick={() => dispatch(addToCart(plant))}>Añadir al carrito</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ProductsPage;
