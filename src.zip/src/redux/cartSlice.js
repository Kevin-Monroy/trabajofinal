import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  items: [], // Aquí guardaremos las plantas en el carrito
};

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addToCart: (state, action) => {
      const plant = action.payload;
      state.items.push(plant);
    },
    removeFromCart: (state, action) => {
      state.items = state.items.filter(item => item.id !== action.payload);
    },
    increaseQuantity: (state, action) => {
      const plant = state.items.find(item => item.id === action.payload);
      if (plant) plant.quantity += 1;
    },
    decreaseQuantity: (state, action) => {
      const plant = state.items.find(item => item.id === action.payload);
      if (plant && plant.quantity > 1) plant.quantity -= 1;
    },
  },
});

export const { addToCart, removeFromCart, increaseQuantity, decreaseQuantity } = cartSlice.actions;
export default cartSlice.reducer;
